"""Module properties trong core giữ trống để tránh trùng lặp."""


def register():
    """Không đăng ký property toàn cục ở core nữa."""


def unregister():
    """Không có property nào để hủy đăng ký trong core."""
