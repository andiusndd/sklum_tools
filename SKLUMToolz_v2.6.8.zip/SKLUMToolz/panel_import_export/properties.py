"""Module rỗng do đã loại bỏ GLB Compression."""


def register():
    """Không cần đăng ký gì."""


def unregister():
    """Không cần hủy đăng ký gì."""
